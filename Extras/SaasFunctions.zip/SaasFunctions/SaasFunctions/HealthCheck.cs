﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace SaasFunctions;

public static class HealthCheck
{
    [FunctionName("HealthCheck")]
    public static async Task<IActionResult> RunAsync(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "health")] HttpRequest req, ILogger log)
    {
        var message = "Azure Functions is alive at " + DateTime.Now;
        log.LogInformation(message);
        return new OkObjectResult(message);
    }
}