﻿namespace SaasFunctions
{
    public class EmailModel
    {
        public string Message { get; set; }
        public string Subject { get; set; }
        public string Email { get; set; }
    }

    /*
     * 
     * {
            "message": "Test message",
            "subject": "Test subject",
            "email": "sendemail@toaddress.net"
        }
     */
}
